"""Aggregate synthetic Monte Carlo results into LaTeX tables and pgfplots CSVs."""
import numpy as np, pandas as pd
from scipy.stats import wilcoxon

OUT = "/home/claude/paper/data/"
df = pd.read_pickle("/home/claude/results/synth_main.pkl")
SHOW = ["Static-GUM", "KF-GUM", "Split-CP", "ACI", "CQT", "NexCP", "SPARC", "SPARC-G"]
ABL = ["SPARC", "SPARC-1", "SPARC-noAge", "SPARC-noACI"]


def sci(x, nd=1):
    if x == 0 or not np.isfinite(x):
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = round(x / 10 ** e, nd)
    if abs(m) >= 10:
        m, e = m / 10, e + 1
    return f"\\num{{{m:.{nd}f}e{e}}}"


def fmt_pv(p):
    if p < 1e-15:
        return "$<10^{-15}$"
    return sci(p, 1)


# ---------------- main table (per scenario, period 168)
def main_table(period, path):
    g = df[df.period == period].groupby(["scenario", "method"]).agg(
        PICP=("PICP", "mean"), PICPsd=("PICP", "std"), MPIW=("MPIW", "mean"), IS=("IS", "mean"),
        ISsd=("IS", "std"), AF=("AFmis", "mean"), ACE=("ACE", "mean"), WW=("WorstWk", "mean"))
    lines = []
    for sc in ["S1", "S2", "S3", "S4"]:
        sub = g.loc[sc]
        best_is = sub.loc[SHOW, "IS"].min()
        best_ace = sub.loc[SHOW, "ACE"].min()
        lines.append(f"\\multicolumn{{7}}{{l}}{{\\textit{{Scenario {sc}}}}}\\\\")
        for m in SHOW:
            r = sub.loc[m]
            isS = f"{r.IS:.3f}"
            if abs(r.IS - best_is) < 1e-12:
                isS = f"\\textbf{{{isS}}}"
            aceS = sci(r.ACE)
            if abs(r.ACE - best_ace) < 1e-12:
                aceS = f"\\textbf{{{aceS}}}"
            lines.append(f"{m} & {r.PICP:.3f} ({r.PICPsd:.3f}) & {r.MPIW:.3f} & {isS} & {sci(r.AF)} & {aceS} & {r.WW:.2f}\\\\")
        lines.append("\\midrule")
    lines = lines[:-1]
    open(path, "w").write("\n".join(lines) + "\n")
    return g


g168 = main_table(168, OUT + "tab_synth_168.tex")

# ---------------- aggregate across all periods/scenarios (12 configs)
agg = df.groupby(["scenario", "period", "method"]).agg(PICP=("PICP", "mean"), IS=("IS", "mean"),
                                                         ACE=("ACE", "mean"), AF=("AFmis", "mean"),
                                                         MPIW=("MPIW", "mean")).reset_index()
rows = []
for m in SHOW + ABL[1:]:
    a = agg[agg.method == m]
    ref = agg[agg.method == "ACI"].set_index(["scenario", "period"]).IS
    ratio = a.set_index(["scenario", "period"]).IS / ref
    rows.append(dict(method=m, minPICP=a.PICP.min(), meanDev=np.mean(np.abs(a.PICP - 0.95)),
                     ACE=a.ACE.mean(), AFdev=np.mean(np.abs(a.AF - 0.05)), ISratio=np.exp(np.mean(np.log(ratio)))))
summ = pd.DataFrame(rows).set_index("method")
summ.to_csv(OUT + "synth_summary.csv")
print(summ.round(4))

# ---------------- per period summary table
lines = []
for per in [72, 168, 336]:
    a = agg[agg.period == per]
    ref = a[a.method == "ACI"].set_index("scenario").IS
    lines.append(f"\\multicolumn{{6}}{{l}}{{\\textit{{Check period $\\Delta={per}$ h}}}}\\\\")
    for m in ["KF-GUM", "Split-CP", "ACI", "CQT", "NexCP", "SPARC", "SPARC-G"]:
        b = a[a.method == m].set_index("scenario")
        lines.append(f"{m} & {b.PICP.min():.3f} & {b.PICP.mean():.3f} & {sci(b.ACE.mean())} & {sci(np.mean(np.abs(b.AF-0.05)))} & {np.exp(np.mean(np.log(b.IS/ref))):.3f}\\\\")
    lines.append("\\midrule")
open(OUT + "tab_synth_periods.tex", "w").write("\n".join(lines[:-1]) + "\n")

# ---------------- Wilcoxon tests SPARC vs others (IS and ACE), all configs pooled per config
tests = []
for (sc, per), sub in df.groupby(["scenario", "period"]):
    piv = sub.pivot_table(index="seed", columns="method", values="IS")
    pa = sub.pivot_table(index="seed", columns="method", values="ACE")
    for m in ["KF-GUM", "Split-CP", "ACI", "CQT", "NexCP", "SPARC-1", "SPARC-noAge", "SPARC-noACI"]:
        p1 = wilcoxon(piv["SPARC"], piv[m]).pvalue
        p2 = wilcoxon(pa["SPARC"], pa[m]).pvalue
        tests.append(dict(scenario=sc, period=per, method=m, dIS=np.median(piv["SPARC"] - piv[m]), pIS=p1,
                          dACE=np.median(pa["SPARC"] - pa[m]), pACE=p2, winIS=np.mean(piv["SPARC"] < piv[m])))
T = pd.DataFrame(tests)
# Holm correction within each family (metric) over all comparisons
for col in ["pIS", "pACE"]:
    p = T[col].values
    o = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    run = 0
    for r, i in enumerate(o):
        run = max(run, (m - r) * p[i])
        adj[i] = min(run, 1.0)
    T[col + "_holm"] = adj
T.to_pickle("/home/claude/results/synth_tests.pkl")
lines = []
for m in ["KF-GUM", "Split-CP", "ACI", "CQT", "NexCP", "SPARC-1", "SPARC-noAge", "SPARC-noACI"]:
    t = T[T.method == m]
    nIS_better = int(((t.dIS < 0) & (t.pIS_holm < 0.05)).sum())
    nIS_worse = int(((t.dIS > 0) & (t.pIS_holm < 0.05)).sum())
    nACE_better = int(((t.dACE < 0) & (t.pACE_holm < 0.05)).sum())
    nACE_worse = int(((t.dACE > 0) & (t.pACE_holm < 0.05)).sum())
    lines.append(f"{m} & {nIS_better} / {nIS_worse} & {100*t.winIS.mean():.0f}\\,\\% & {nACE_better} / {nACE_worse} & {fmt_pv(t.pACE_holm.median())}\\\\")
open(OUT + "tab_tests.tex", "w").write("\n".join(lines) + "\n")
print(T.groupby("method")[["dIS", "winIS"]].mean().round(4))

# ---------------- staleness-conditional coverage CSVs (truth), period 336 and 168
for per in [168, 336]:
    edges = np.linspace(0, per + 24, 6)
    mid = 0.5 * (edges[:-1] + edges[1:])
    for sc in ["S1", "S2", "S3", "S4"]:
        cols = {"a": mid}
        for m, nm in [("ACI", "ACI"), ("KF-GUM", "KFGUM"), ("SPARC", "SPARC"), ("SPARC-G", "SPARCG"),
                      ("NexCP", "NexCP"), ("SPARC-noAge", "noAge"), ("Split-CP", "Split")]:
            sub = df[(df.period == per) & (df.scenario == sc) & (df.method == m)]
            cols[nm] = sub[[f"cb{i}" for i in range(5)]].mean().values
        pd.DataFrame(cols).to_csv(OUT + f"agecov_{sc}_{per}.csv", index=False)

# ---------------- ablation table (all 12 configs, mean over seeds)
lines = []
for m in ABL:
    a = agg[agg.method == m]
    ref = agg[agg.method == "SPARC"].set_index(["scenario", "period"]).IS
    lines.append(f"{m} & {a.PICP.mean():.3f} & {a.PICP.min():.3f} & {sci(np.mean(np.abs(a.AF-0.05)))} & {sci(a.ACE.mean())} & {np.exp(np.mean(np.log(a.set_index(['scenario','period']).IS/ref))):.3f}\\\\")
open(OUT + "tab_ablation_synth.tex", "w").write("\n".join(lines) + "\n")
print(open(OUT + "tab_ablation_synth.tex").read())
