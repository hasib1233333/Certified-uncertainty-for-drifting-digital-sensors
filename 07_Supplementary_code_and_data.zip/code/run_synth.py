"""Monte Carlo benchmark on the synthetic in-service sensor twin."""
import numpy as np, pandas as pd, sys, time
from multiprocessing import Pool
from sparc import run_stream, interval_metrics, METHODS, age_coverage
from synth import generate, periodic_windows, INIT, U_REF

ALPHA = 0.05


def age_ace(y, lo, hi, ages, period, nb=5):
    m = ~np.isnan(lo) & ~np.isnan(ages)
    cov = ((y >= lo) & (y <= hi))[m]
    a = ages[m]
    edges = np.linspace(0, period + 24, nb + 1)
    b = np.clip(np.digitize(a, edges) - 1, 0, nb - 1)
    covs = np.array([cov[b == i].mean() if np.any(b == i) else np.nan for i in range(nb)])
    return float(np.nanmax(np.abs(covs - (1 - ALPHA)))), covs


def one(args):
    sc, period, seed, gamma, uref_mult, W = args
    H, y, yr = generate(sc, seed)
    if uref_mult != 1.0:
        rng = np.random.default_rng(10_000 + seed)
        yr = y + rng.normal(0, U_REF * uref_mult, len(y))
    res, ex = run_stream(H, yr, INIT, periodic_windows(period, W), u_ref=U_REF * uref_mult,
                         gamma=gamma, W=W)
    af, chk, ages, nc = ex["af"], ex["chk"], ex["ages"], ex["n_checks"]
    yt, yrr = y[INIT:], yr[INIT:]
    rows = []
    for k in METHODS:
        yhat, lo, hi = res[k]
        mt = interval_metrics(yt, lo, hi)
        mr = interval_metrics(yrr, lo, hi)
        ace, covs = age_ace(yt, lo, hi, ages, period)
        acer, covsr = age_ace(yrr, lo, hi, ages, period)
        rmse = float(np.sqrt(np.nanmean((yhat - yt) ** 2)))
        rows.append(dict(scenario=sc, period=period, seed=seed, gamma=gamma, uref=uref_mult, W=W,
                         method=k, PICP=mt["PICP"], PICPref=mr["PICP"], MPIW=mt["MPIW"],
                         IS=mt["IS"], WorstWk=mt["WorstWk"], AFmis=float(np.mean(af[k])),
                         nAF=len(af[k]), CHKmis=float(np.mean(chk[k])), nCHK=len(chk[k]), ACE=ace, ACEref=acer, RMSE=rmse, checks=nc,
                         **{f"cb{i}": covs[i] for i in range(5)},
                         **{f"cbr{i}": covsr[i] for i in range(5)}))
    return rows


if __name__ == "__main__":
    mode = sys.argv[1]
    R = int(sys.argv[2])
    jobs = []
    if mode == "main":
        for sc in ["S1", "S2", "S3", "S4"]:
            for period in [72, 168, 336]:
                for seed in range(R):
                    jobs.append((sc, period, seed, 0.01, 1.0, 24))
    elif mode == "sens":
        for g in [0.002, 0.005, 0.02, 0.05]:
            for seed in range(R):
                jobs.append(("S1", 168, seed, g, 1.0, 24))
        for um in [0.0, 0.5, 2.0, 3.0]:
            for seed in range(R):
                jobs.append(("S1", 168, seed, 0.01, um, 24))
        for W in [6, 12, 48]:
            for seed in range(R):
                jobs.append(("S1", 168, seed, 0.01, 1.0, W))
    t0 = time.time()
    with Pool(2) as p:
        out = p.map(one, jobs, chunksize=2)
    df = pd.DataFrame([r for rr in out for r in rr])
    df.to_pickle(f"/home/claude/results/synth_{mode}.pkl")
    print("done", len(jobs), "jobs in %.1f s" % (time.time() - t0))
