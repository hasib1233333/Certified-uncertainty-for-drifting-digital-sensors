import numpy as np, pandas as pd, os
OUT = "/home/claude/paper/data/"


def sci(x, nd=1):
    if x == 0 or not np.isfinite(x):
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = round(x / 10 ** e, nd)
    if abs(m) >= 10:
        m, e = m / 10, e + 1
    return f"\\num{{{m:.{nd}f}e{e}}}"


if os.path.exists("/home/claude/results/synth_sens.pkl"):
    s = pd.read_pickle("/home/claude/results/synth_sens.pkl")
    base = pd.read_pickle("/home/claude/results/synth_main.pkl")
    base = base[(base.scenario == "S1") & (base.period == 168) & (base.seed < 30)].assign(gamma=0.01, uref=1.0, W=24)
    s = pd.concat([s, base])
    lines = []
    for name, col, vals in [("$\\gamma$", "gamma", [0.002, 0.005, 0.01, 0.02, 0.05]),
                            ("$u_{\\mathrm{ref}}/\\SI{0.08}{mg.m^{-3}}$", "uref", [0.0, 0.5, 1.0, 2.0, 3.0]),
                            ("$W$ (h)", "W", [6, 12, 24, 48])]:
        for v in vals:
            q = s
            for c, dv in [("gamma", 0.01), ("uref", 1.0), ("W", 24)]:
                q = q[np.isclose(q[c], v if c == col else dv)]
            g = q.groupby("method").mean(numeric_only=True)
            r = lambda m, k: g.loc[m, k]
            lines.append(f"{name if v == vals[0] else ''} & {v:g} & {r('SPARC','PICP'):.3f} & {r('SPARC','PICPref'):.3f} & {sci(abs(r('SPARC','AFmis')-0.05))} & {r('SPARC','IS'):.3f} & {r('SPARC-G','PICP'):.3f} & {r('SPARC-G','IS'):.3f} & {r('ACI','PICP'):.3f} & {r('ACI','IS'):.3f}\\\\")
        lines.append("\\midrule")
    open(OUT + "tab_sens.tex", "w").write("\n".join(lines[:-1]) + "\n")
    print("\n".join(lines))

if os.path.exists("/home/claude/results/sched.pkl"):
    d = pd.read_pickle("/home/claude/results/sched.pkl")
    g = d.groupby(["policy", "val"]).mean(numeric_only=True).reset_index()
    for pol in ["periodic", "UT"]:
        g[g.policy == pol].sort_values("checks")[["val", "checks", "PICP", "MPIW", "FFP", "MPEcomp", "RMSE"]].to_csv(
            OUT + f"sched_{pol}.csv", index=False)
    print(g.round(3).to_string())
    # per-sensor allocation for UT 0.5 vs periodic 168
    a = d[((d.policy == "UT") & (d.val == 0.5)) | ((d.policy == "periodic") & (d.val == 168))]
    print(a.groupby(["policy", "mult"])[["checks", "FFP", "PICP"]].mean().round(3))
    a.groupby(["policy", "mult"])[["checks", "FFP", "PICP"]].mean().reset_index().to_csv(OUT + "sched_alloc.csv", index=False)
