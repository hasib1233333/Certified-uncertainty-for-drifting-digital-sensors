import numpy as np, pandas as pd
from scipy.optimize import nnls
from run_real import load, features, INIT, TARGETS
from sparc import run_stream
from synth import generate, periodic_windows, INIT as SI, U_REF
OUT="/home/claude/paper/data/"
D=load(); H=features(D)
# ---- (1) kappa trajectories, field (weekly) ----
traj={}
for tgt in ["CO","NO2"]:
    y=D[tgt+"(GT)"].values.astype(float)
    res,ex=run_stream(H,y,INIT,list(range(INIT+168-24,len(y),168)))
    h=np.array(ex["meths"]["SPARC"][0].hist)
    k=np.arange(len(h))//12  # one row per as-left audit; ~12 per check
    df=pd.DataFrame(h,columns=["n","kF","kL"]); df["check"]=k
    g=df.groupby("check").last().reset_index(); g.to_csv(OUT+f"kappa_{tgt}.csv",index=False)
    traj[tgt]=g; print(tgt, g[["kF","kL"]].describe().round(3).T)
# ---- (2) endpoint-error sensitivity (synthetic S1,S2, Delta=336, 20 seeds) ----
rows=[]
for sc in ["S1","S2"]:
    for seed in range(20):
        Hs,yy,yr=generate(sc,seed)
        res,ex=run_stream(Hs,yr,SI,periodic_windows(336),u_ref=U_REF)
        yh,lo,hi=res["SPARC"]; U=(hi-lo)/2; a=ex["ages"]; yt=yy[SI:]
        mid=(a>60)&(a<280)&~np.isnan(U)
        for dlt in [-0.10,-0.05,-0.02,0.0,0.02,0.05,0.10]:
            c=np.abs(yt[mid]-yh[mid])<=U[mid]*(1+dlt)
            rows.append((sc,seed,dlt,c.mean()))
R=pd.DataFrame(rows,columns=["sc","seed","d","cov"]).groupby(["sc","d"])["cov"].mean().unstack(0).reset_index()
R.to_csv(OUT+"endpoint_sens.csv",index=False); print(R.round(4))
# ---- (3) identifiability: NNLS parameter recovery ----
rng=np.random.default_rng(1); phi=np.array([2e-4,1e-3,4e-2])  # q_z, q_s, r0
def design(kind,n):
    if kind=="F+L, varied |y|": a=np.where(rng.random(n)<0.5,rng.uniform(1,12,n),rng.uniform(156,168,n)); y=rng.lognormal(0.6,0.5,n)
    elif kind=="F only, varied |y|": a=rng.uniform(156,168,n); y=rng.lognormal(0.6,0.5,n)
    elif kind=="F+L, constant |y|": a=np.where(rng.random(n)<0.5,rng.uniform(1,12,n),rng.uniform(156,168,n)); y=np.full(n,1.8)+rng.normal(0,0.02,n)
    else: a=np.full(n,162.0); y=np.full(n,1.8)
    return a,y
rec=[]
for kind in ["F+L, varied |y|","F only, varied |y|","F+L, constant |y|","F only, constant a and |y|"]:
    for n in [600,2400]:
        ests=[]
        for r in range(200):
            a,y=design(kind,n); X=np.column_stack([a,a*np.abs(y),np.ones(n)])
            v=X@phi; e=rng.normal(0,np.sqrt(v)); cs=np.sqrt((X**2).mean(0))+1e-12
            x,_=nnls(X/cs,e**2); ests.append(x/cs)
        E=np.array(ests); G=X.T@X/n; cond=np.linalg.cond(G/np.outer(cs,cs))
        rel=np.sqrt(((E-phi)**2).mean(0))/phi
        rec.append((kind,n,cond,*rel))
Rec=pd.DataFrame(rec,columns=["design","n","cond","qz","qs","r0"]); print(Rec.round(3))
def sci(x):
    e=int(np.floor(np.log10(abs(x)))); m=round(x/10**e,1)
    if m>=10: m,e=m/10,e+1
    return f"\\num{{{m:.1f}e{e}}}"
lines=[f"{r.design} & {r.n} & {sci(r.cond)} & {r.qz:.2f} & {r.qs:.2f} & {r.r0:.2f}\\\\" for r in Rec.itertuples()]
open(OUT+"tab_ident.tex","w").write("\n".join(lines)+"\n")
# ---- (6) block-length robustness of field CIs ----
L=[]
for tgt,(col,u) in TARGETS.items():
    y=D[col].values.astype(float)
    for per in [72,168,336]:
        res,ex=run_stream(H,y,INIT,list(range(INIT+per-24,len(y),per))); yt=y[INIT:]
        for B in [168,336,504]:
            nb=len(yt)//B
            def wk(k):
                _,lo,hi=res[k]; c=((yt>=lo)&(yt<=hi)).astype(float); c[np.isnan(yt)|np.isnan(lo)]=np.nan
                return c[:nb*B].reshape(nb,B)
            S,A,K=wk("SPARC"),wk("ACI"),wk("KF-GUM")
            usable=int(np.sum(np.isfinite(np.nanmean(S,1))))
            out=[]
            for X,Y in [(S,A),(S,K)]:
                d=[np.nanmean(X[i])-np.nanmean(Y[i]) for i in [rng.integers(0,nb,nb) for _ in range(2000)]]
                lo_,hi_=np.percentile(d,[2.5,97.5]); out.append((lo_>0) - (hi_<0))
            L.append((tgt,per,B,usable,*out))
Bk=pd.DataFrame(L,columns=["t","p","B","nblocks","sigA","sigK"])
Bk.to_csv(OUT+"blocklen.csv",index=False)
print(Bk.groupby("B").agg(nb_min=("nblocks","min"),nb_max=("nblocks","max"),A_pos=("sigA",lambda s:(s>0).sum()),A_neg=("sigA",lambda s:(s<0).sum()),K_pos=("sigK",lambda s:(s>0).sum()),K_neg=("sigK",lambda s:(s<0).sum())))
# lag-1 autocorrelation of weekly coverage differences
ac=[]
for tgt,(col,u) in TARGETS.items():
    y=D[col].values.astype(float); res,ex=run_stream(H,y,INIT,list(range(INIT+168-24,len(y),168))); yt=y[INIT:]; nb=len(yt)//168
    def w(k):
        _,lo,hi=res[k]; c=((yt>=lo)&(yt<=hi)).astype(float); c[np.isnan(yt)|np.isnan(lo)]=np.nan; return np.nanmean(c[:nb*168].reshape(nb,168),1)
    dd=w("SPARC")-w("ACI"); dd=dd[np.isfinite(dd)]; ac.append(np.corrcoef(dd[:-1],dd[1:])[0,1])
print("lag1 autocorr weekly diff", np.round(ac,3))
