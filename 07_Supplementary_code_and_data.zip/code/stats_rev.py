import numpy as np, pandas as pd
from scipy import stats
from run_real import load, features, INIT, TARGETS
from sparc import run_stream
OUT="/home/claude/paper/data/"
def sci(x, nd=1):
    if x == 0 or not np.isfinite(x): return "0"
    e = int(np.floor(np.log10(abs(x)))); m = round(x/10**e, nd)
    if abs(m) >= 10: m, e = m/10, e+1
    return f"\\num{{{m:.{nd}f}e{e}}}"
# synthetic paired effects
df=pd.read_pickle('/home/claude/results/synth_main.pkl')
rows=[]
for (sc,per),sub in df.groupby(['scenario','period']):
    P=sub.pivot_table(index='seed',columns='method',values='PICP'); I=sub.pivot_table(index='seed',columns='method',values='IS')
    for m in ['ACI','KF-GUM']:
        dp=P['SPARC']-P[m]; n=len(dp); h=stats.t.ppf(0.975,n-1)*dp.std(ddof=1)/np.sqrt(n)
        di=I['SPARC']-I[m]; w=stats.wilcoxon(di)
        # matched-pairs rank-biserial correlation
        r=np.sign(di)*stats.rankdata(np.abs(di)); rb=(r[r<0].sum()*-1 - r[r>0].sum())/np.abs(r).sum()
        rows.append(dict(sc=sc,per=per,m=m,dP=dp.mean(),lo=dp.mean()-h,hi=dp.mean()+h,dIS=np.median(di/I[m]),rb=rb))
T=pd.DataFrame(rows)
lines=[]
for per in [72,168,336]:
    for sc in ['S1','S2','S3','S4']:
        a=T[(T.sc==sc)&(T.per==per)&(T.m=='ACI')].iloc[0]; b=T[(T.sc==sc)&(T.per==per)&(T.m=='KF-GUM')].iloc[0]
        f=lambda x: f"{100*x:+.2f}"
        lines.append(f"{per if sc=='S1' else ''} & {sc} & {f(a.dP)} [{f(a.lo)}, {f(a.hi)}] & {100*a.dIS:+.1f} & {a.rb:.2f} & {f(b.dP)} [{f(b.lo)}, {f(b.hi)}] & {100*b.dIS:+.1f} & {b.rb:.2f}\\\\")
    lines.append("\\midrule")
open(OUT+'tab_effects_synth.tex','w').write("\n".join(lines[:-1])+"\n")
print(T.round(4).to_string())
# field paired block bootstrap of PICP difference (weekly blocks)
D=load(); H=features(D); rng=np.random.default_rng(0); L=[]
for tgt,(col,u) in TARGETS.items():
    y=D[col].values.astype(float)
    for per in [72,168,336]:
        res,ex=run_stream(H,y,INIT,list(range(INIT+per-24,len(y),per)))
        yt=y[INIT:]; nb=len(yt)//168
        def wk(k):
            _,lo,hi=res[k]; c=((yt>=lo)&(yt<=hi)).astype(float); c[np.isnan(yt)|np.isnan(lo)]=np.nan
            return c[:nb*168].reshape(nb,168)
        S,A,K=wk('SPARC'),wk('ACI'),wk('KF-GUM')
        def boot(X,Y):
            d=[]
            for _ in range(2000):
                i=rng.integers(0,nb,nb); d.append(np.nanmean(X[i])-np.nanmean(Y[i]))
            return np.nanmean(X)-np.nanmean(Y), *np.percentile(d,[2.5,97.5])
        L.append((tgt,per,*boot(S,A),*boot(S,K)))
F=pd.DataFrame(L,columns=['t','p','dA','loA','hiA','dK','loK','hiK'])
print(F.round(4))
NAME={"CO":"CO","NO2":"NO$_2$","NOx":"NO$_x$","C6H6":"C$_6$H$_6$"}
lines=[]
for _,r in F.iterrows():
    f=lambda x: f"{100*x:+.2f}"
    lines.append(f"{NAME[r.t] if r.p==72 else ''} & {r.p} & {f(r.dA)} [{f(r.loA)}, {f(r.hiA)}] & {f(r.dK)} [{f(r.loK)}, {f(r.hiK)}]\\\\")
    if r.p==336: lines.append("\\midrule")
open(OUT+'tab_effects_real.tex','w').write("\n".join(lines[:-1])+"\n")
F.to_csv(OUT+'effects_real.csv',index=False)
