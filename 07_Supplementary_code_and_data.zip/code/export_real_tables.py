import numpy as np, pandas as pd
OUT = "/home/claude/paper/data/"
d = pd.read_pickle("/home/claude/results/real.pkl")
W = pd.read_pickle("/home/claude/results/real_wilcoxon.pkl")
M = ["ACI", "NexCP", "KF-GUM", "SPARC"]
NAME = {"CO": "CO", "NO2": "NO$_2$", "NOx": "NO$_x$", "C6H6": "C$_6$H$_6$"}


def sci(x, nd=1):
    if x == 0 or not np.isfinite(x):
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = round(x / 10 ** e, nd)
    if abs(m) >= 10:
        m, e = m / 10, e + 1
    return f"\\num{{{m:.{nd}f}e{e}}}"


lines = []
for tgt in ["CO", "NO2", "NOx", "C6H6"]:
    for per in [72, 168, 336]:
        sub = d[(d.target == tgt) & (d.period == per)].set_index("method")
        pic = sub.loc[M, "PICP"]
        dev = (pic - 0.95).abs()
        IS = sub.loc[M, "IS"]
        cells = []
        for m in M:
            s = f"{pic[m]:.3f}"
            if dev[m] == dev.min():
                s = f"\\textbf{{{s}}}"
            cells.append(s)
        for m in M:
            v = IS[m]
            s = f"{v:.3g}" if v < 100 else f"{v:.0f}"
            if v == IS.min():
                s = f"\\textbf{{{s}}}"
            cells.append(s)
        afa, afs = sub.loc["ACI", "AFmis"], sub.loc["SPARC", "AFmis"]
        lab = NAME[tgt] if per == 72 else ""
        lines.append(f"{lab} & {per} & " + " & ".join(cells) + f" & {sci(afa)} & {sci(afs)}\\\\")
    lines.append("\\midrule")
open(OUT + "tab_real.tex", "w").write("\n".join(lines[:-1]) + "\n")

# summary over the 12 field deployments
rows = []
ref = d[d.method == "ACI"].set_index(["target", "period"]).IS
for m in ["Static-GUM", "KF-GUM", "Split-CP", "ACI", "CQT", "NexCP", "SPARC", "SPARC-1", "SPARC-noAge", "SPARC-noACI"]:
    a = d[d.method == m].set_index(["target", "period"])
    rows.append(dict(method=m, minPICP=a.PICP.min(), meanPICP=a.PICP.mean(), meanDev=np.mean(np.abs(a.PICP - 0.95)),
                     ACE=a.ACE.mean(), AFdev=np.mean(np.abs(a.AFmis - 0.05)), AFmax=a.AFmis.max(),
                     ISratio=float(np.exp(np.mean(np.log(a.IS / ref))))))
S = pd.DataFrame(rows).set_index("method")
S.to_csv(OUT + "real_summary.csv")
print(S.round(4))
lines = []
for m, r in S.iterrows():
    lines.append(f"{m} & {r.minPICP:.3f} & {r.meanPICP:.3f} & {sci(r.meanDev)} & {sci(r.ACE)} & {sci(r.AFdev)} & {r.ISratio:.3f}\\\\")
open(OUT + "tab_real_summary.tex", "w").write("\n".join(lines) + "\n")
print(W.groupby("method")[["dIS", "frac_better"]].mean().round(3))
print(W[["target", "period", "method", "p", "dIS"]].round(4).to_string())
