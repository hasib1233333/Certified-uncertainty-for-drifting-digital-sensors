"""Serialise SPARC outputs as D-SI <si:real> records and validate them against the official
D-SI XML schemas (v1.3.1 and v2.2.1, PTB; obtained from a public mirror)."""
import numpy as np, pandas as pd
from lxml import etree

NS = "https://ptb.de/si"
UNIT = {"CO": r"\milli\gram\metre\tothe{-3}", "NO2": r"\micro\gram\metre\tothe{-3}",
        "C6H6": r"\micro\gram\metre\tothe{-3}", "NOx": r"\nano\mole\mole\tothe{-1}"}
DIST = ("SPARC; coverage audited distribution-free at reference checks only (as-found/as-left ACI); "
        "between checks: conditional on staleness-transfer assumption; reference-referred (u_ref not removed)")


def record(label, value, unit, ts, U, k, p=0.95, schema="2.2.1", age=None, chk=False):
    E = lambda tag, text=None, parent=None: _el(tag, text, parent)
    r = etree.Element(f"{{{NS}}}real", nsmap={"si": NS})
    for tag, txt in (("label", label), ("value", f"{value:.4f}"), ("unit", unit),
                     ("dateTime", ts.strftime("%Y-%m-%dT%H:%M:%SZ"))):
        etree.SubElement(r, f"{{{NS}}}{tag}").text = txt
    if schema == "2.2.1":
        mu = etree.SubElement(etree.SubElement(r, f"{{{NS}}}measurementUncertaintyUnivariate"), f"{{{NS}}}expandedMU")
        names = ("valueExpandedMU", "coverageFactor", "coverageProbability", "distribution")
    else:
        mu = etree.SubElement(r, f"{{{NS}}}expandedUnc")
        names = ("uncertainty", "coverageFactor", "coverageProbability", "distribution")
    dist = DIST + (f"; staleness={int(age)} h" if age is not None else "")
    dist += "; scope=audited-check-instant" if chk else "; scope=between-checks"
    for tag, txt in zip(names, (f"{U:.4f}", f"{k:.3f}", f"{p:.2f}", dist)):
        etree.SubElement(mu, f"{{{NS}}}{tag}").text = txt
    return r


if __name__ == "__main__":
    S = pd.read_pickle("/home/claude/results/real_series.pkl")
    idx = pd.read_pickle("/home/claude/results/real_index.pkl")[336:]
    out = []
    for v, path in (("1.3.1", "/home/claude/dsi/SI_v1.3.1.xsd"), ("2.2.1", "/home/claude/dsi/v/dsi/v2.2.1/SI_Format.xsd")):
        schema = etree.XMLSchema(etree.parse(path))
        n_ok = n = 0
        errs = []
        for tgt in ["CO", "NO2", "NOx", "C6H6"]:
            yh, lo, hi = S[(tgt, "SPARC")]
            kap = S[(tgt, "kappa")]
            ages = S[(tgt, "ages")]
            inchk = np.zeros(len(ages), bool)
            for s0 in S[(tgt, "starts")]:
                inchk[max(s0 - 336, 0):s0 - 336 + 24] = True
            for i in np.where(~np.isnan(lo) & ~np.isnan(kap))[0]:
                U = (hi[i] - lo[i]) / 2
                r = record(f"{tgt}, AQ multisensor", yh[i], UNIT[tgt], idx[i], U, max(kap[i], 1.0), schema=v, age=ages[i], chk=bool(inchk[i]))
                n += 1
                if schema.validate(r):
                    n_ok += 1
                elif len(errs) < 3:
                    errs.append(str(schema.error_log.last_error))
        out.append((v, n, n_ok, errs))
        print(f"D-SI {v}: {n_ok}/{n} records valid", errs[:2])
        if v == "2.2.1":
            print(etree.tostring(r, pretty_print=True).decode())
    pd.DataFrame([o[:3] for o in out], columns=["version", "n", "valid"]).to_csv("/home/claude/paper/data/dsi_validation.csv", index=False)
