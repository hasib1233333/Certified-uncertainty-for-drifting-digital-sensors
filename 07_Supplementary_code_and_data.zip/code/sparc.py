"""
SPARC -- Staleness-aware, Prior-informed, Adaptive, Reference-sparse Conformal uncertainty
for in-service digital sensors that are verified only at sparse reference checks.

Library: (i) calibration-state digital twin (Kalman filter on calibration coefficients) with
an online-identified zero/span drift budget, (ii) as-found / as-left reference checks,
(iii) online interval constructors (proposed + baselines), (iv) evaluation metrics.

Reference implementation accompanying the manuscript; all experiments call run_stream().
"""
import numpy as np
from scipy.optimize import nnls

ALPHA = 0.05
BUF_M = 1000          # score-buffer length M
Z_ALPHA = 1.959963984540054


# --------------------------------------------------------------------------------------
# Calibration-state digital twin
# --------------------------------------------------------------------------------------
class CalibrationKF:
    """
    theta_t = theta_{t-1} + w_t,   w_t ~ N(0, Q_t),  Q_t = q_z e1 e1' + (q_s / ybar) theta theta'
    y_ref,t = h_t' theta_t + v_t,  v_t ~ N(0, r0)

    Uncertainty budget used by SPARC (staleness a = hours since last adjustment):
        u^2(a, yhat) = r0 + a (q_z + q_s |yhat|)          (noise + zero drift + span drift)
    The components (q_z, q_s, r0) are identified by weighted non-negative least squares on
    squared check residuals with exponential forgetting (covariance matching).
    """

    def __init__(self, H0, y0, forget=0.97):
        H0 = np.asarray(H0, float)
        n, p = H0.shape
        G = H0.T @ H0 + 1e-8 * np.eye(p)
        Gi = np.linalg.inv(G)
        theta = Gi @ (H0.T @ y0)
        r = y0 - H0 @ theta
        s2 = float(r @ r) / max(n - p, 1)
        lev = np.einsum("ij,jk,ik->i", H0, Gi, H0)
        rs = r / np.sqrt(np.clip(1 - lev, 1e-3, None))      # studentised residuals
        self.theta, self.P, self.p = theta, Gi * s2, p
        self.r0 = s2
        self.r0_floor = 0.25 * s2           # noise cannot vanish below 1/4 of the initial residual variance
        self.qz, self.qs = 1e-4 * s2, 0.0
        self.ybar = max(float(np.mean(np.abs(y0))), 1e-9)
        self.forget = forget
        self.rows = [np.column_stack([np.zeros(n), np.zeros(n), np.ones(n)])]
        self.targ = [rs ** 2]
        self.wts = [np.ones(n)]
        self.init_resid = rs
        self.init_yhat = H0 @ theta
        self.t_upd = None

    # ----- uncertainty budget
    def u2(self, ages, yhat):
        return self.r0 + np.asarray(ages) * (self.qz + self.qs * np.abs(yhat))

    def predict(self, H, ages):
        yhat = H @ self.theta
        hPh = np.einsum("ij,jk,ik->i", H, self.P, H)
        drift = ages * (self.qz + self.qs * np.abs(yhat))
        var_kf = hPh + drift + self.r0          # textbook KF predictive variance
        return yhat, var_kf

    def identify(self, ages, yhat, resid):
        rows = np.column_stack([ages, ages * np.abs(yhat), np.ones(len(ages))])
        self.wts = [w * self.forget for w in self.wts]
        self.rows.append(rows)
        self.targ.append(resid ** 2)
        self.wts.append(np.ones(len(ages)))
        A = np.vstack(self.rows)
        b = np.concatenate(self.targ)
        w = np.sqrt(np.concatenate(self.wts))
        cs = np.sqrt(np.mean(A ** 2, 0)) + 1e-12
        x, _ = nnls((A * w[:, None]) / cs, b * w)
        x = x / cs
        self.qz, self.qs, self.r0 = x[0], x[1], max(x[2], self.r0_floor)

    def update(self, H, y, t_idx, t_last):
        tprev = t_last
        for h, yy, t in zip(H, y, t_idx):
            a = t - tprev
            Q = (self.qs / self.ybar) * np.outer(self.theta, self.theta)
            Q[0, 0] += self.qz
            P = self.P + a * Q
            yh = h @ self.theta
            S = h @ P @ h + self.r0
            K = P @ h / S
            self.theta = self.theta + K * (yy - yh)
            self.P = P - np.outer(K, h @ P)
            self.P = 0.5 * (self.P + self.P.T)
            tprev = t
        return tprev


# --------------------------------------------------------------------------------------
# Score buffer: raw residuals are stored with their staleness and reading, and are
# re-standardised with the *current* budget whenever a quantile is requested.
# --------------------------------------------------------------------------------------
class ScoreBuffer:
    def __init__(self, kf, kind, M=1000):
        self.kf, self.kind, self.M = kf, kind, M
        self.e = list(np.abs(kf.init_resid))
        self.a = list(np.zeros(len(kf.init_resid)))
        self.y = list(kf.init_yhat)

    def add(self, e, a, y):
        self.e.append(abs(e)); self.a.append(a); self.y.append(y)

    def scale(self, a, y):
        if self.kind == "abs":
            return np.ones_like(np.asarray(a, float))
        if self.kind == "age0":
            return np.sqrt(self.kf.r0) * np.ones_like(np.asarray(a, float))
        return np.sqrt(self.kf.u2(a, y))

    def scores(self):
        e = np.asarray(self.e[-self.M:]); a = np.asarray(self.a[-self.M:]); y = np.asarray(self.y[-self.M:])
        return e / self.scale(a, y)


def _quant(s, level):
    if level >= 1.0:
        return float(np.max(s))          # finite surrogate of the infinite ACI set
    if level <= 0.0:
        return 0.0
    return float(np.quantile(s, level, method="higher"))


class SplitCP:
    """Static split-conformal multiplier from the initial co-location."""

    def __init__(self, buf, alpha=ALPHA):
        self.buf, self.alpha = buf, alpha
        s = buf.scores()
        n = len(s)
        self.val = _quant(s, np.ceil((1 - alpha) * (n + 1)) / n)

    def q(self, part=0):
        return self.val

    def qa(self, ages):
        return np.full(len(ages), self.val)

    def update(self, e, err, part, a, y):
        pass


class ACI:
    """Adaptive conformal inference (Gibbs & Candes, 2021)."""

    def __init__(self, buf, alpha=ALPHA, gamma=0.01):
        self.buf, self.alpha, self.gamma, self.at = buf, alpha, gamma, alpha

    def q(self, part=0):
        return _quant(self.buf.scores(), 1 - self.at)

    def qa(self, ages):
        return np.full(len(ages), self.q())

    def update(self, e, err, part, a, y):
        self.viol = getattr(self, "viol", 0) + int(self.at <= 0 and err > 0)
        self.at += self.gamma * (self.alpha - err)
        self.buf.add(e, a, y)


class StratACI:
    """Staleness-stratified ACI (proposed): separate ACI recursions audit the as-found
    (part 0, large staleness) and as-left (part 1, small staleness) scores; deployment
    multipliers are interpolated in staleness between the two audited end points."""

    def __init__(self, buf, alpha=ALPHA, gamma=0.01):
        self.buf, self.alpha, self.gamma = buf, alpha, gamma
        self.at = {0: alpha, 1: alpha}
        self.age = {0: None, 1: None}
        self.hist = []          # (n_audits, kappa_F, kappa_L) after every audit

    def q(self, part=0):
        return _quant(self.buf.scores(), 1 - self.at[part])

    def qa(self, ages):
        s = self.buf.scores()
        qF, qL = _quant(s, 1 - self.at[0]), _quant(s, 1 - self.at[1])
        aF, aL = self.age[0], self.age[1]
        if aF is None or aL is None or aF <= aL:
            return np.full(len(ages), qF)
        w = np.clip((np.asarray(ages) - aL) / (aF - aL), 0.0, 1.0)
        return qL + w * (qF - qL)

    def update(self, e, err, part, a, y):
        # surrogate events: finite set used while alpha<=0 and the new score exceeded it
        self.viol = getattr(self, "viol", 0) + int(self.at[part] <= 0 and err > 0)
        self.at[part] += self.gamma * (self.alpha - err)
        self.buf.add(e, a, y)
        self.age[part] = a if self.age[part] is None else 0.9 * self.age[part] + 0.1 * a
        if part == 1:
            sc = self.buf.scores()
            self.hist.append((len(self.buf.e), _quant(sc, 1 - self.at[0]), _quant(sc, 1 - self.at[1])))


class QuantileTracker:
    """Quantile tracking / conformal P-control (Angelopoulos et al., 2023)."""

    def __init__(self, buf, alpha=ALPHA, eta_frac=0.05):
        s = buf.scores()
        self.buf, self.alpha = buf, alpha
        self.val = _quant(s, 1 - alpha)
        self.eta = eta_frac * float(np.max(s))

    def q(self, part=0):
        return max(self.val, 0.0)

    def qa(self, ages):
        return np.full(len(ages), self.q())

    def update(self, e, err, part, a, y):
        self.val += self.eta * (err - self.alpha)
        self.buf.add(e, a, y)


class WeightedCP:
    """Non-exchangeable conformal prediction (Barber et al., 2023), exponential weights."""

    def __init__(self, buf, alpha=ALPHA, rho=0.99):
        self.buf, self.alpha, self.rho = buf, alpha, rho

    def q(self, part=0):
        b = self.buf.scores()
        n = len(b)
        w = np.append(self.rho ** np.arange(n - 1, -1, -1), 1.0)
        w = w / w.sum()
        o = np.argsort(b)
        idx = np.searchsorted(np.cumsum(w[:-1][o]), 1 - self.alpha)
        return float(b.max()) if idx >= n else float(b[o][idx])

    def qa(self, ages):
        return np.full(len(ages), self.q())

    def update(self, e, err, part, a, y):
        self.buf.add(e, a, y)


METHODS = ["Static-GUM", "KF-GUM", "Split-CP", "ACI", "CQT", "NexCP",
           "SPARC", "SPARC-G", "SPARC-1", "SPARC-noAge", "SPARC-noACI"]


def make_methods(kf, alpha=ALPHA, gamma=0.01):
    B = lambda kind: ScoreBuffer(kf, kind, BUF_M)
    return {  # name -> (constructor, reference-uncertainty correction?)
        "Split-CP": (SplitCP(B("abs"), alpha), False),
        "ACI": (ACI(B("abs"), alpha, gamma), False),
        "CQT": (QuantileTracker(B("abs"), alpha), False),
        "NexCP": (WeightedCP(B("abs"), alpha), False),
        "SPARC": (StratACI(B("age"), alpha, gamma), False),
        "SPARC-G": (StratACI(B("age"), alpha, gamma), True),
        "SPARC-1": (ACI(B("age"), alpha, gamma), False),
        "SPARC-noAge": (StratACI(B("age0"), alpha, gamma), False),
        "SPARC-noACI": (SplitCP(B("age"), alpha), False),
    }


def ref_correct(hw, u_ref, z=Z_ALPHA, floor=0.2):
    """Measurand-referred half-width: H = sqrt(H_ref^2 - z^2 u_ref^2) (exact if Gaussian)."""
    if u_ref <= 0:
        return hw
    hw = np.asarray(hw, float)
    return np.sqrt(np.maximum(hw ** 2 - (z * u_ref) ** 2, (floor * hw) ** 2))


# --------------------------------------------------------------------------------------
# Stream runner
# --------------------------------------------------------------------------------------
def run_stream(H, y_ref, init_end, windows=None, u_ref=0.0, alpha=ALPHA, gamma=0.01, W=24,
               scheduler=None, max_gap=720, min_gap=24):
    """
    H: (N,p) regressors incl. intercept (rows with NaN: sensor unavailable)
    y_ref: (N,) reference values (NaN where no reference); only hours inside check windows
           and the initial co-location [0, init_end) are ever used for learning.
    windows: start indices of periodic checks, or scheduler(U, idx, t_min) for
             uncertainty-triggered checks.
    """
    N, p = H.shape
    H = np.array(H, float)
    i0 = np.arange(init_end)
    mu, sd = np.nanmean(H[i0, 1:], 0), np.nanstd(H[i0, 1:], 0) + 1e-12
    H[:, 1:] = (H[:, 1:] - mu) / sd
    m0 = ~np.isnan(y_ref[i0]) & ~np.isnan(H[i0]).any(1)
    kf = CalibrationKF(H[i0][m0], y_ref[i0][m0])
    kf.t_upd = init_end - 1
    th_static = kf.theta.copy()
    s_static = float(np.sqrt(np.mean(kf.init_resid ** 2)))
    meths = make_methods(kf, alpha, gamma)

    T = N - init_end
    out = {k: [np.full(T, np.nan) for _ in range(3)] for k in METHODS}
    ages_all = np.full(T, np.nan)
    kappa_all = np.full(T, np.nan)        # audited coverage factor of SPARC
    u_all = np.full(T, np.nan)            # standard uncertainty of SPARC budget
    chk_log = {k: [] for k in METHODS}      # all check hours (as-found + as-left)
    af_log = {k: [] for k in METHODS}       # as-found hours only
    check_starts = []
    feat_ok = ~np.isnan(H).any(1)
    n_checks = 0

    def emit(idx, part=None):
        """Issue intervals for hours idx with the current (frozen) state.  If part is given
        the hours are check hours: feedback is processed sequentially."""
        Hs = H[idx]
        ages = (idx - kf.t_upd).astype(float)
        yhat, var_kf = kf.predict(Hs, ages)
        j = idx - init_end
        ages_all[j] = ages
        ys = Hs @ th_static
        for nm, c, hw in (("Static-GUM", ys, 2 * s_static), ("KF-GUM", yhat, 2 * np.sqrt(var_kf))):
            out[nm][0][j], out[nm][1][j], out[nm][2][j] = c, c - hw, c + hw
        if part is None:
            for nm, (obj, corr) in meths.items():
                kap = obj.qa(ages)
                sc = obj.buf.scale(ages, yhat)
                if nm == "SPARC":
                    kappa_all[j], u_all[j] = kap, sc
                hw = kap * sc
                if corr:
                    hw = ref_correct(hw, u_ref)
                out[nm][0][j], out[nm][1][j], out[nm][2][j] = yhat, yhat - hw, yhat + hw
            return None
        yr = y_ref[idx]
        has = ~np.isnan(yr)
        for i in range(len(idx)):
            if has[i]:
                for nm, c, hw in (("Static-GUM", ys[i], 2 * s_static),
                                  ("KF-GUM", yhat[i], 2 * np.sqrt(var_kf[i]))):
                    err = float(abs(yr[i] - c) > hw)
                    chk_log[nm].append(err)
                    if part == 0:
                        af_log[nm].append(err)
            for nm, (obj, corr) in meths.items():
                kap = obj.q(part)
                sc = obj.buf.scale(ages[i:i + 1], yhat[i:i + 1])[0]
                if nm == "SPARC":
                    kappa_all[j[i]], u_all[j[i]] = kap, sc
                hw_ref = kap * sc
                hw = ref_correct(hw_ref, u_ref) if corr else hw_ref
                out[nm][0][j[i]], out[nm][1][j[i]], out[nm][2][j[i]] = yhat[i], yhat[i] - hw, yhat[i] + hw
                if has[i]:
                    e = yr[i] - yhat[i]
                    err = float(abs(e) > hw_ref)            # audited against the reference
                    obj.update(e, err, part, ages[i], yhat[i])
                    chk_log[nm].append(err)
                    if part == 0:
                        af_log[nm].append(err)
        return has, Hs, ages, yhat, yr

    def fill(t0, t1):
        idx = np.arange(t0, t1)
        idx = idx[feat_ok[idx]]
        if len(idx):
            emit(idx)

    def check(t0):
        """Reference check on [t0, t0+W): as-found half, adjustment, as-left half, adjustment."""
        nonlocal n_checks
        idx_all = np.arange(t0, min(t0 + W, N))
        idx_all = idx_all[feat_ok[idx_all]]
        half = int(np.ceil(len(idx_all) / 2))
        did = False
        for part, idx in enumerate((idx_all[:half], idx_all[half:])):
            if len(idx) == 0:
                continue
            has, Hs, ages, yhat, yr = emit(idx, part)
            if has.sum():
                kf.identify(ages[has], yhat[has], yr[has] - yhat[has])
                kf.t_upd = kf.update(Hs[has], yr[has], idx[has], kf.t_upd)
                did = True
        n_checks += int(did)
        check_starts.append(t0)

    t = init_end
    if scheduler is None:
        for w0 in windows:
            if w0 >= N:
                break
            fill(t, w0)
            check(w0)
            t = min(w0 + W, N)
        fill(t, N)
    else:
        while t < N:
            idx = np.arange(t, min(t + max_gap, N))
            ok = feat_ok[idx]
            ages = (idx - kf.t_upd).astype(float)
            yhat, _ = kf.predict(np.where(ok[:, None], H[idx], 0.0), ages)
            sp = meths["SPARC"][0]
            U = sp.qa(ages) * sp.buf.scale(ages, yhat)
            U[~ok] = 0.0
            w0 = scheduler(U, idx, t + min_gap)
            if w0 is None or w0 >= N:
                fill(t, N)
                break
            fill(t, w0)
            check(w0)
            t = min(w0 + W, N)
    res = {k: tuple(v) for k, v in out.items()}
    extra = dict(chk=chk_log, af=af_log, ages=ages_all, n_checks=n_checks, kf=kf,
                 meths=meths, starts=check_starts, kappa=kappa_all, u=u_all)
    return res, extra


# --------------------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------------------
def interval_metrics(y, lo, hi, alpha=ALPHA, roll=168):
    m = ~np.isnan(y) & ~np.isnan(lo)
    y, lo, hi = y[m], lo[m], hi[m]
    cov = (y >= lo) & (y <= hi)
    width = hi - lo
    IS = width + (2 / alpha) * (np.maximum(lo - y, 0) + np.maximum(y - hi, 0))
    nb = len(cov) // roll
    wc = float(np.min(cov[: nb * roll].reshape(nb, roll).mean(1))) if nb else np.nan
    return dict(PICP=float(cov.mean()), MPIW=float(np.mean(width)), IS=float(np.mean(IS)),
                WorstWk=wc, n=int(m.sum()))


def age_coverage(y, lo, hi, ages, period, nb=5):
    m = ~np.isnan(lo) & ~np.isnan(y) & ~np.isnan(ages)
    cov = ((y >= lo) & (y <= hi))[m]
    edges = np.linspace(0, period + 24, nb + 1)
    b = np.clip(np.digitize(ages[m], edges) - 1, 0, nb - 1)
    return np.array([cov[b == i].mean() if np.any(b == i) else np.nan for i in range(nb)])
