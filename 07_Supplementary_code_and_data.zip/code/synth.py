"""Synthetic in-service sensor digital twin with known ground truth (four drift scenarios)."""
import numpy as np

INIT = 336          # 14-day initial co-location
TDEP = 8760         # one year of deployment (hourly)
U_REF = 0.08        # reference analyser standard uncertainty (mg/m^3)


def generate(scenario, seed, drift_mult=1.0):
    rng = np.random.default_rng(seed)
    N = INIT + TDEP
    t = np.arange(N, dtype=float)
    # measurand: CO-like concentration, log-normal with diurnal/weekly cycles + AR(1)
    ar = np.zeros(N)
    e = rng.normal(0, 0.12, N)
    for k in range(1, N):
        ar[k] = 0.95 * ar[k - 1] + e[k]
    logy = (np.log(1.8) + 0.35 * np.sin(2 * np.pi * (t - 7) / 24)
            + 0.15 * np.sin(2 * np.pi * t / 168) + ar)
    y = np.exp(logy)
    # influence quantities
    T = 15 + 8 * np.sin(2 * np.pi * (t - 2000) / 8760) + 4 * np.sin(2 * np.pi * (t - 9) / 24) \
        + rng.normal(0, 0.8, N)
    RH = np.clip(60 - 1.5 * (T - 15) + rng.normal(0, 4, N), 10, 98)

    g0, b0, c0, d0 = 1.0, 0.4, 0.03, -0.004
    sg, sb = 1.5e-3 * drift_mult, 1.0e-2 * drift_mult        # per-hour random-walk intensities
    g = g0 * np.exp(np.cumsum(rng.normal(0, sg, N)))
    b = b0 + np.cumsum(rng.normal(0, sb, N))
    c = c0 * np.ones(N)
    d = d0 * np.ones(N)
    if scenario == "S2":   # ageing (sensitivity loss) + seasonal change of cross-sensitivity
        g = g0 * (1 - 0.25 * t / N) * np.exp(np.cumsum(rng.normal(0, 0.3 * sg, N)))
        b = b0 + 0.6 * t / N + np.cumsum(rng.normal(0, 0.3 * sb, N))
        c = c0 * (1 + 0.8 * np.sin(2 * np.pi * (t - 1000) / 8760))
    if scenario == "S3":   # abrupt relocation/maintenance events
        g = g0 * np.exp(np.cumsum(rng.normal(0, 0.3 * sg, N)))
        b = b0 + np.cumsum(rng.normal(0, 0.3 * sb, N))
        for _ in range(3):
            k = rng.integers(INIT + 500, N - 200)
            b[k:] += rng.choice([-1, 1]) * rng.uniform(0.25, 0.45)
            g[k:] *= rng.uniform(0.85, 1.15)
    noise_sd = 0.04 + 0.04 * y                       # heteroscedastic transducer noise
    if scenario == "S0":   # well-specified Gaussian case: additive baseline random walk, homoscedastic noise
        g = g0 * np.ones(N)
        b = b0 + np.cumsum(rng.normal(0, sb, N))
        noise_sd = 0.11 * np.ones(N)
    if scenario == "S4":   # heavy-tailed noise + spikes
        n = noise_sd * rng.standard_t(3, N) / np.sqrt(3.0)
        spk = rng.random(N) < 0.01
        n[spk] += rng.normal(0, 0.6, spk.sum())
    else:
        n = noise_sd * rng.normal(0, 1, N)
    x = g * y + b + c * (T - 15) + d * (RH - 60) + n
    y_ref = y + rng.normal(0, U_REF, N)
    H = np.column_stack([np.ones(N), x, T - 15, RH - 60])
    return H, y, y_ref


def periodic_windows(period, W=24):
    return list(range(INIT + period - W, INIT + TDEP, period))
