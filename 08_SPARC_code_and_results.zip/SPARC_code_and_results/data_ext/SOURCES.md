Hourly series derived from public data (no other changes than hourly averaging):
- london_MER.csv, london_KEMP.csv: QM Air Quality Network Data v1.0.1, A.A. Mercado-Velazquez, Zenodo, doi:10.5281/zenodo.23482843. Node data CC BY 4.0; reference-station data from the London Air Quality Network under the Open Government Licence. Produced by prep_ext.py.
- zurich_pm25.csv: data of S. Mahajan and D. Helbing, npj Clim. Atmos. Sci. (2025), doi:10.1038/s41612-025-01145-2, from github.com/sachit27/Trust-Based-Calibration-for-Low-Cost-PM2.5-Sensors (CC0).
