"""Field evaluation on two additional public data sets (London QMUL AQMS; Zurich Empa PM2.5)."""
import numpy as np, pandas as pd, sys
from scipy.stats import wilcoxon
from sparc import run_stream, interval_metrics, METHODS, age_coverage
from run_real import weekly_blocks
D = "/home/claude/data_ext"
def london(site, analyte):
    d = pd.read_csv(f"{D}/london_{site}.csv", index_col=0)
    if analyte == "NO2":
        X = d[["no2_mid_alphasense_op1_voltage", "no2_mid_alphasense_op2_voltage", "o3_mid_alphasense_op1_voltage",
               "o3_mid_alphasense_op2_voltage", "temperature_low_sht45_celsius", "humidity_low_sht45_percentage"]].values
        y = d["ref_no2"].values
    else:
        X = d[["pm2_5_low_sps30_ug_m3", "pm10_low_sps30_ug_m3", "temperature_low_sht45_celsius",
               "humidity_low_sht45_percentage"]].values
        y = d["ref_pm25"].values
    return np.column_stack([np.ones(len(X)), X]), y.astype(float)
def zurich(s):
    d = pd.read_csv(f"{D}/zurich_pm25.csv", index_col=0)
    return np.column_stack([np.ones(len(d)), d[s].values]), d["Ref"].values.astype(float)
CASES = [("London", f"{a}-{s}", (lambda s=s, a=a: london(s, a)), [72, 168, 336], 24, 336)
         for s in ["MER", "KEMP"] for a in ["NO2", "PM25"]]
CASES += [("Zurich", f"PM25-{s}", (lambda s=s: zurich(s)), [48, 72, 120], 12, 240) for s in ["S1", "S2", "S3", "S4"]]
rows, wk = [], []
for ds, name, f, periods, W, init in CASES:
    H, y = f()
    for P in periods:
        wins = list(range(init + P - W, len(y), P))
        res, ex = run_stream(H, y, init, wins, u_ref=0.0, W=W)
        yt = y[init:]; ages = ex["ages"]; isw = {}
        for k in METHODS:
            if k == "SPARC-G": continue
            yh, lo, hi = res[k]
            mt = interval_metrics(yt, lo, hi)
            cb = age_coverage(yt, lo, hi, ages, P)
            isw[k] = weekly_blocks(yt, lo, hi, B=168 if ds == "London" else 48)[0]
            rows.append(dict(dataset=ds, case=name, period=P, method=k, PICP=mt["PICP"], IS=mt["IS"],
                             AF=float(np.mean(ex["af"][k])), nAF=len(ex["af"][k]), ACE=float(np.nanmax(np.abs(cb - .95))),
                             n=mt["n"], checks=ex["n_checks"], kappa=float(np.nanmean(ex["kappa"]))))
        for k in ["ACI", "KF-GUM", "NexCP", "CQT"]:
            a, b = isw["SPARC"], isw[k]; m = ~np.isnan(a) & ~np.isnan(b)
            p = wilcoxon(a[m], b[m]).pvalue if m.sum() > 5 else np.nan
            wk.append(dict(dataset=ds, case=name, period=P, method=k, p=p, dIS=float(np.mean(a[m] - b[m])), nb=int(m.sum())))
        print(ds, name, P, "checks", ex["n_checks"], {k: round(r["PICP"], 3) for r in rows[-10:] for k in [r["method"]]}, flush=True)
pd.DataFrame(rows).to_pickle("/home/claude/results/ext.pkl"); pd.DataFrame(wk).to_pickle("/home/claude/results/ext_wilcoxon.pkl")
