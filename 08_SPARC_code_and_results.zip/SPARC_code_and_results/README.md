Title: SPARC code and results

Description: Python code, synthetic sensor generator, three field data sets, stored results and scripts that reproduce and verify every table and figure of the SPARC paper.

Repository: https://github.com/hasib1233333/Certified-uncertainty-for-drifting-digital-sensors

# SPARC – reproducibility package



Python 3.13, NumPy, SciPy, pandas.

| File | Purpose |
|---|---|
| `sparc.py` | Method library: calibration-state twin, zero/span budget (NNLS), stratified ACI, baselines, metrics |
| `synth.py` | Synthetic in-service sensor generator (scenarios S1–S4) |
| `run_synth.py main 100` | 1200 Monte Carlo deployments (Tables 2–5, Fig. 3) |
| `run_synth.py sens 30` | Sensitivity analysis (Table 8) |
| `run_real.py` | Field evaluation on UCI Air Quality (Tables 6–7) |
| `run_sched.py` | Uncertainty-triggered scheduling study (Fig. 7) |
| `export_*.py` | Write the LaTeX tables and pgfplots CSV files in `paper/data/` |

Field data: UCI Air Quality (De Vito, 2008), doi:10.24432/C59K5F; place `AirQualityUCI_clean.csv`
(comma-separated, -200 = missing) in `data/` or edit the path in `run_real.py`.
| `run_rev.py` | Revision runs: buffer size M, well-specified Gaussian scenario S0 (Table 9) |
| `stats_rev.py` | Paired effect sizes and weekly-block bootstrap CIs (Tables 5, 7) |
| `dsi_export.py` | Serialise all field outputs as D-SI records and validate against D-SI XSD 1.3.1 and 2.2.1 |
| `rev2.py` | Round-2 revision: kappa trajectories, endpoint sensitivity, NNLS identifiability study, block-length robustness |


## Additional field data sets
- `prep_ext.py`: builds hourly London and Zurich series from the public raw files (see data_ext/SOURCES.md).
- `run_ext.py`: runs all methods on the 24 additional deployments (Fig. 6 of the article; Tables S8-S9 of the supplement).

## Stored results and verification
- `results/`: all result files produced by the experiment scripts (pandas pickles and logs).
- `figure_and_table_data/`: the CSV and table files read by the LaTeX figures and tables.
- `verify_results.py`: recomputes every headline number of the manuscript from `results/` and compares it with the text; `results/verification_report.txt` is its output (112 checks, 0 failures).
