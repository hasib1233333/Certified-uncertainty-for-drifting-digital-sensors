"""Export field-evaluation results to CSV/TeX for pgfplots figures and tables."""
import numpy as np, pandas as pd
from run_real import load, features, INIT, TARGETS
from sparc import run_stream, ALPHA

OUT = "figure_data/"
import os; os.makedirs(OUT, exist_ok=True)
d = pd.read_pickle("results/real.pkl")
S = pd.read_pickle("results/real_series.pkl")
idx = pd.read_pickle("results/real_index.pkl")

# ---- coverage vs period (per analyte)
for tgt in TARGETS:
    sub = d[d.target == tgt].pivot_table(index="period", columns="method", values="PICP")
    sub[["ACI", "NexCP", "KF-GUM", "SPARC"]].rename(columns={"KF-GUM": "KFGUM"}).to_csv(OUT + f"cov_{tgt}.csv")

# ---- staleness-conditional coverage, field, period 336 averaged over analytes
for per in [168, 336]:
    rows = []
    for m in ["ACI", "KF-GUM", "SPARC", "SPARC-noAge"]:
        sub = d[(d.period == per) & (d.method == m)][[f"cb{i}" for i in range(5)]].mean().values
        rows.append(sub)
    edges = np.linspace(0, per + 24, 6)
    mid = 0.5 * (edges[:-1] + edges[1:])
    pd.DataFrame(np.column_stack([mid] + rows), columns=["a", "ACI", "KFGUM", "SPARC", "noAge"]).to_csv(
        OUT + f"agecov_real_{per}.csv", index=False)

# ---- time series excerpt (CO, period 168)
y = S[("CO", "y")]; lo_s, hi_s = S[("CO", "SPARC")][1:]; lo_a, hi_a = S[("CO", "ACI")][1:]
yh = S[("CO", "SPARC")][0]
ts = idx[INIT:]
t0 = np.where(ts >= pd.Timestamp("2004-11-08"))[0][0]
t1 = t0 + 21 * 24
day = (np.arange(t0, t1) - t0) / 24.0
starts = np.array(S[("CO", "starts")]) - INIT
chk = np.zeros(t1 - t0)
for s0 in starts:
    for h in range(s0, s0 + 24):
        if t0 <= h < t1:
            chk[h - t0] = 1 if h - s0 < 12 else 2
df = pd.DataFrame(dict(day=day, ref=y[t0:t1], yhat=yh[t0:t1], slo=lo_s[t0:t1], shi=hi_s[t0:t1],
                       alo=lo_a[t0:t1], ahi=hi_a[t0:t1], chk=chk))
df = df.replace([np.inf, -np.inf], np.nan)
df.to_csv(OUT + "ts_co.csv", index=False, na_rep="nan")
# check-window spans for shading
spans = []
for s0 in starts:
    if t0 <= s0 < t1:
        spans.append(((s0 - t0) / 24, (s0 - t0 + 12) / 24, (s0 - t0 + 24) / 24))
pd.DataFrame(spans, columns=["f0", "f1", "l1"]).to_csv(OUT + "ts_co_checks.csv", index=False)
print("excerpt start", ts[t0], "checks", spans)

# ---- D-SI example: an unreferenced hour in the excerpt with large staleness
kap = S[("CO", "kappa")]; uu = S[("CO", "u")]; ages = S[("CO", "ages")]
cand = [i for i in range(t0, t1) if not np.isnan(kap[i]) and ages[i] > 100 and not np.isnan(y[i])]
i = cand[len(cand) // 2]
U = (hi_s[i] - lo_s[i]) / 2
print("DSI example", ts[i], "yhat %.2f U %.2f kappa %.2f u %.2f age %d ref %.2f" % (yh[i], U, kap[i], uu[i], ages[i], y[i]))
open(OUT + "dsi_example.txt", "w").write(f"{ts[i]}|{yh[i]:.2f}|{U:.2f}|{kap[i]:.2f}|{int(ages[i])}|{y[i]:.2f}\n")

# ---- Theorem 1 empirical check (as-found stratum, field, period 168)
df_raw = load(); H = features(df_raw)
rows = []
for tgt, (col, unit) in TARGETS.items():
    yy = df_raw[col].values.astype(float)
    res, ex = run_stream(H, yy, INIT, list(range(INIT + 168 - 24, len(yy), 168)))
    e = np.asarray(ex["af"]["SPARC"])
    n = np.arange(1, len(e) + 1)
    dev = np.abs(np.cumsum(e) / n - ALPHA)
    rows.append(pd.DataFrame(dict(n=n, dev=dev, target=tgt)))
    ea = np.asarray(ex["af"]["ACI"]); na = np.arange(1, len(ea) + 1)
    rows.append(pd.DataFrame(dict(n=na, dev=np.abs(np.cumsum(ea) / na - ALPHA), target=tgt + "_ACI")))
R = pd.concat(rows)
for tgt in R.target.unique():
    r = R[R.target == tgt]
    sel = np.unique(np.round(np.geomspace(1, len(r), 60)).astype(int)) - 1
    r.iloc[sel][["n", "dev"]].assign(dev=lambda z: np.maximum(z.dev, 1e-4)).to_csv(OUT + f"thm1_{tgt}.csv", index=False)
nmax = int(R.n.max())
nn = np.geomspace(1, nmax, 60)
pd.DataFrame(dict(n=nn, b=(max(ALPHA, 1 - ALPHA) + 0.01) / (0.01 * nn))).to_csv(OUT + "thm1_bound.csv", index=False)
print("Thm1 final deviations:", R.groupby("target").dev.last().round(4).to_dict())
