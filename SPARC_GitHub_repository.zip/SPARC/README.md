# SPARC: certified uncertainty for drifting digital sensors

Code, data and results for the paper

> Md Hasibuzzaman and Chan-Yun Yang, *Certified uncertainty for drifting digital sensors between sparse reference checks using staleness stratified conformal prediction*.

## Folder layout
| Folder | Contents |
|---|---|
| `./` | Python scripts (run from this folder) |
| `data/` | Field data set 1: UCI Air Quality (De Vito et al. 2008), CC BY 4.0 |
| `data_ext/` | Field data sets 2 and 3: London (QM Air Quality Network, CC BY 4.0 / OGL) and Zurich (Mahajan and Helbing 2025, CC0); see `DATA_SOURCES.txt` |
| `results/` | Stored results (pandas pickles) and `verification_report.txt` |
| `figure_data/` | CSV files read by the figures and tables of the paper |
| `dsi_schemas/` | Official D-SI XML schemas used to validate the uncertainty records |

## Scripts
| Script | Purpose |
|---|---|
| `sparc.py` | SPARC and all baseline methods |
| `synth.py` | Synthetic sensor twin (scenarios S0-S4) |
| `run_synth.py` | Synthetic study (`python run_synth.py main 100`) |
| `run_real.py` | Field data set 1 (Italy) |
| `prep_ext.py` | Builds the hourly London and Zurich series from the public raw files |
| `run_ext.py` | Field data sets 2 and 3 (London, Zurich) |
| `run_sched.py` | Uncertainty-triggered scheduling study |
| `run_rev.py`, `rev2.py`, `rev2b.py`, `stats_rev.py` | Sensitivity, transfer, identifiability and statistical analyses |
| `export_*.py` | Write the files in `figure_data/` |
| `dsi_export.py` | Writes and validates the D-SI XML records |
| `verify_results.py` | Recomputes every headline number of the paper from `results/` (112 checks) |

## Requirements
Python 3.11 or newer with numpy, scipy, pandas and lxml. All random seeds are fixed, and re-running the scripts reproduces the stored results exactly.
