"""Recompute every headline number reported in the manuscript from the stored results and compare."""
import pandas as pd, numpy as np, re, sys
R = "results/"
ok, bad = 0, []
def chk(name, value, stated, tol):
    global ok
    if abs(value - stated) <= tol: ok += 1; print(f"  OK   {name}: computed {value:.4g}  stated {stated}")
    else: bad.append(name); print(f"  FAIL {name}: computed {value:.4g}  stated {stated}")
def rng(name, vals, lo, hi, tol):
    chk(name + " (min)", float(np.min(vals)), lo, tol); chk(name + " (max)", float(np.max(vals)), hi, tol)

print("== Synthetic study (1200 deployments)")
s = pd.read_pickle(R + "synth_main.pkl")
assert s.seed.nunique() == 100 and s.scenario.nunique() == 4 and s.period.nunique() == 3
g = s.groupby(["scenario", "period", "method"]).mean(numeric_only=True).reset_index()
w = g[g.period == 168]
rng("Static-GUM PICP, all configs", g[g.method == "Static-GUM"].PICP, 0.42, 0.60, 0.006)
rng("Split-CP PICP, all configs", g[g.method == "Split-CP"].PICP, 0.85, 0.91, 0.006)
pooled = w[w.method.isin(["ACI", "CQT", "NexCP"])]
rng("pooled PICP (168h)", pooled.PICP, 0.933, 0.951, 0.0006)
rng("pooled AF (168h)", pooled.AFmis, 0.054, 0.071, 0.0006)
rng("pooled ACE (168h)", pooled.ACE, 0.031, 0.057, 0.0006)
k = g[g.method == "KF-GUM"]
chk("KF-GUM min PICP all configs", k.PICP.min(), 0.923, 0.0006)
chk("KF-GUM PICP S2 168", w[(w.method == "KF-GUM") & (w.scenario == "S2")].PICP.iloc[0], 0.931, 0.0006)
chk("KF-GUM PICP S1 168", w[(w.method == "KF-GUM") & (w.scenario == "S1")].PICP.iloc[0], 0.956, 0.0006)
best_is = w.loc[w[~w.method.isin(["SPARC-G"])].groupby("scenario").IS.idxmin()].method.unique()
chk("KF-GUM lowest IS in every scenario (168h) [1=yes]", float(list(best_is) == ["KF-GUM"]), 1, 0)
sp = w[w.method == "SPARC"]
rng("SPARC PICP (168h)", sp.PICP, 0.944, 0.954, 0.0006)
rng("SPARC AF (168h)", sp.AFmis, 0.048, 0.052, 0.0006)
rng("SPARC ACE (168h)", sp.ACE, 0.026, 0.036, 0.0006)
low_ace = w[~w.method.isin(["Static-GUM", "Split-CP", "SPARC-G"])].groupby("scenario").apply(lambda d: d.loc[d.ACE.idxmin(), "method"])
chk("SPARC lowest ACE in all four scenarios (168h) [count]", float((low_ace == "SPARC").sum()), 4, 0)
afdev = g.assign(d=lambda x: (x.AFmis - 0.05).abs()).groupby("method").d.mean()
chk("mean |AF-a| SPARC", afdev["SPARC"], 1.5e-3, 6e-5); chk("mean |AF-a| KF-GUM", afdev["KF-GUM"], 9.4e-3, 6e-5); chk("mean |AF-a| ACI", afdev["ACI"], 1.28e-2, 6e-5)
ace = g.groupby("method").ACE.mean()
chk("mean ACE SPARC", ace["SPARC"], 2.8e-2, 6e-4); chk("mean ACE KF-GUM", ace["KF-GUM"], 3.4e-2, 6e-4); chk("mean ACE ACI", ace["ACI"], 4.1e-2, 6e-4)
isr = (g[g.method == "SPARC"].set_index(["scenario", "period"]).IS / g[g.method == "ACI"].set_index(["scenario", "period"]).IS)
per = isr.groupby(level="period").apply(lambda x: np.exp(np.mean(np.log(x))))
rng("IS reduction vs ACI by period, %", 100 * (1 - per.values), 3.4, 6.5, 0.06)
kfr = (g[g.method == "KF-GUM"].set_index(["scenario", "period"]).IS / g[g.method == "SPARC"].set_index(["scenario", "period"]).IS).groupby(level="period").apply(lambda x: np.exp(np.mean(np.log(x))))
chk("max IS gap SPARC vs KF-GUM by period, % (about 4)", 100 * (1 - kfr.min()), 4.0, 0.6)
t = pd.read_pickle(R + "synth_tests.pkl")
for m, n in [("ACI", 12), ("CQT", 10), ("NexCP", 9)]:
    x = t[t.method == m]; chk(f"Holm IS SPARC<{m} [count]", float(((x.pIS_holm < .05) & (x.dIS < 0)).sum()), n, 0)
for m in ["ACI", "CQT", "NexCP"]:
    x = t[t.method == m]; chk(f"Holm ACE SPARC<{m} [count]", float(((x.pACE_holm < .05) & (x.dACE < 0)).sum()), 12, 0)
x = t[t.method == "KF-GUM"]
chk("Holm ACE SPARC<KF-GUM [count]", float(((x.pACE_holm < .05) & (x.dACE < 0)).sum()), 8, 0)
chk("Holm IS KF-GUM<SPARC [count]", float(((x.pIS_holm < .05) & (x.dIS > 0)).sum()), 12, 0)
chk("ablation |AF-a| SPARC-1", afdev["SPARC-1"], 8.5e-3, 6e-5)
chk("ablation |AF-a| SPARC-noACI", afdev["SPARC-noACI"], 8.8e-3, 6e-5)
chk("ablation ACE increase SPARC-noAge, %", 100 * (ace["SPARC-noAge"] / ace["SPARC"] - 1), 20, 1.5)
ism = g.groupby("method").IS.apply(lambda x: np.exp(np.mean(np.log(x))))
chk("ablation IS increase SPARC-noAge, %", 100 * (ism["SPARC-noAge"] / ism["SPARC"] - 1), 3.3, 0.3)
chk("ablation min PICP SPARC-noACI", g[g.method == "SPARC-noACI"].PICP.min(), 0.921, 0.0006)

print("== Field data set 1 (Italy, UCI)")
r = pd.read_pickle(R + "real.pkl"); spr = r[r.method == "SPARC"]; aci = r[r.method == "ACI"]; kf = r[r.method == "KF-GUM"]
rng("SPARC AF", spr.AFmis, 0.046, 0.062, 0.0006)
chk("SPARC mean |AF-a|", (spr.AFmis - .05).abs().mean(), 4.5e-3, 6e-5)
rng("ACI AF", aci.AFmis, 0.029, 0.090, 0.0006)
chk("ACI mean |AF-a|", (aci.AFmis - .05).abs().mean(), 1.8e-2, 6e-4)
chk("KF-GUM max AF", kf.AFmis.max(), 0.171, 0.0006)
rng("ACI benzene AF", aci[aci.target == "C6H6"].AFmis, 0.072, 0.090, 0.0006)
for m, v, mn in [("SPARC", 1.16e-2, .920), ("ACI", 1.59e-2, .913), ("NexCP", 1.78e-2, .907), ("CQT", 3.44e-2, .828), ("KF-GUM", 3.85e-2, .855)]:
    x = r[r.method == m]; chk(f"{m} mean |PICP-0.95|", (x.PICP - .95).abs().mean(), v, 6e-5); chk(f"{m} min PICP", x.PICP.min(), mn, 0.0006)
ir = np.exp(np.mean(np.log(spr.set_index(["target", "period"]).IS / aci.set_index(["target", "period"]).IS)))
chk("IS ratio SPARC/ACI, %", 100 * (ir - 1), 1.8, 0.06)
wk = pd.read_pickle(R + "real_wilcoxon.pkl")
chk("weekly Wilcoxon SPARC vs ACI significant [count]", float((wk[wk.method == "ACI"].p < .05).sum()), 0, 0)
x = wk[wk.method == "KF-GUM"]; chk("KF-GUM significantly lower IS [count]", float(((x.p < .05) & (x.dIS > 0)).sum()), 4, 0)
for tg, v in [("CO", .060), ("NOx", .052)]:
    chk(f"SPARC AF {tg} 336h", spr[(spr.target == tg) & (spr.period == 336)].AFmis.iloc[0], v, 0.0006)
    chk(f"SPARC PICP {tg} 336h (about 0.92)", spr[(spr.target == tg) & (spr.period == 336)].PICP.iloc[0], 0.92, 0.006)
rs = pd.read_pickle(R + "real_series.pkl")
for tg, a, b in [("CO", 2.69, 2.21), ("NOx", 3.19, 2.77)]:
    chk(f"mean k_eff {tg} 336h", rs[(tg, 336, "budget")][3], a, 0.006); chk(f"mean k_eff {tg} 72h", rs[(tg, 72, "budget")][3], b, 0.006)
chk("k_eff > 2 [count of 12]", float(sum(rs[(tg, p, "budget")][3] > 2 for tg in ["CO", "NO2", "NOx", "C6H6"] for p in [72, 168, 336])), 11, 0)

print("== Field data sets 2 and 3 (London, Zurich)")
e = pd.read_pickle(R + "ext.pkl"); ew = pd.read_pickle(R + "ext_wilcoxon.pkl")
assert (e.groupby("dataset").case.nunique() == 4).all()
L = e[e.dataset == "London"]; Z = e[e.dataset == "Zurich"]
def mdev(d, m, col, tgt): return (d[d.method == m][col] - tgt).abs().mean()
chk("London SPARC mean |AF-a|", mdev(L, "SPARC", "AF", .05), 6.5e-3, 6e-5)
chk("London ACI mean |AF-a|", mdev(L, "ACI", "AF", .05), 2.4e-2, 6e-4); chk("London KF mean |AF-a|", mdev(L, "KF-GUM", "AF", .05), 2.4e-2, 6e-4)
chk("London NexCP mean |AF-a|", mdev(L, "NexCP", "AF", .05), 2.1e-2, 6e-4)
chk("London SPARC max AF", L[L.method == "SPARC"].AF.max(), 0.066, 0.0006); chk("London ACI max AF", L[L.method == "ACI"].AF.max(), 0.109, 0.0006)
chk("London KF max AF", L[L.method == "KF-GUM"].AF.max(), 0.158, 0.0006)
chk("London SPARC ACE", L[L.method == "SPARC"].ACE.mean(), 3.5e-2, 6e-4); chk("London ACI ACE", L[L.method == "ACI"].ACE.mean(), 6.9e-2, 6e-4)
chk("London KF ACE", L[L.method == "KF-GUM"].ACE.mean(), 3.5e-2, 6e-4)
for m, v in [("NexCP", 8.8e-3), ("SPARC", 1.4e-2), ("ACI", 1.6e-2), ("KF-GUM", 1.6e-2)]: chk(f"London {m} mean |PICP-0.95|", mdev(L, m, "PICP", .95), v, 6e-4 if v > 1e-2 else 6e-5)
def isr(d):
    a = d[d.method == "SPARC"].set_index(["case", "period"]).IS; b = d[d.method == "ACI"].set_index(["case", "period"]).IS
    return np.exp(np.mean(np.log(a / b)))
chk("London IS reduction vs ACI, %", 100 * (1 - isr(L)), 2.1, 0.06)
x = ew[(ew.dataset == "London") & (ew.method == "ACI")]
chk("London SPARC sig better than ACI [count]", float(((x.p < .05) & (x.dIS < 0)).sum()), 2, 0); chk("London SPARC sig worse than ACI [count]", float(((x.p < .05) & (x.dIS > 0)).sum()), 1, 0)
for ds in ["London", "Zurich"]:
    x = ew[(ew.dataset == ds) & (ew.method == "KF-GUM")]; chk(f"{ds} KF sig lower IS [count]", float(((x.p < .05) & (x.dIS > 0)).sum()), 4, 0)
chk("London k_eff > 2 [count]", float((L[L.method == "SPARC"].kappa > 2).sum()), 8, 0)
zm = Z[Z.method.isin(["KF-GUM", "ACI", "CQT", "NexCP", "SPARC", "SPARC-1"])].groupby("method").PICP.mean()
rng("Zurich mean coverage of online methods", zm.values, 0.907, 0.921, 0.0006)
rng("Zurich checks per deployment", Z.checks, 7, 19, 0)
chk("Zurich SPARC mean |PICP-0.95|", mdev(Z, "SPARC", "PICP", .95), 3.2e-2, 6e-4); chk("Zurich ACI mean |PICP-0.95|", mdev(Z, "ACI", "PICP", .95), 3.9e-2, 6e-4)
chk("Zurich KF mean |PICP-0.95|", mdev(Z, "KF-GUM", "PICP", .95), 3.5e-2, 6e-4)
chk("Zurich SPARC mean |AF-a|", mdev(Z, "SPARC", "AF", .05), 3.9e-2, 6e-4); chk("Zurich SPARC-1 mean |AF-a|", mdev(Z, "SPARC-1", "AF", .05), 3.3e-2, 6e-4)
za = Z.groupby("method").ACE.mean()
chk("Zurich SPARC ACE below every baseline [1=yes]", float(za["SPARC"] < za[["Static-GUM", "KF-GUM", "Split-CP", "ACI", "CQT", "NexCP"]].min()), 1, 0)
tot_not_worse = 12 + (12 - 1) + (12 - int(((ew[(ew.dataset == "Zurich") & (ew.method == "ACI")].p < .05) & (ew[(ew.dataset == "Zurich") & (ew.method == "ACI")].dIS > 0)).sum()))
chk("deployments with IS not significantly worse than ACI [of 36]", float(tot_not_worse), 34, 0)

print("== Scheduling study")
sc = pd.read_pickle(R + "sched.pkl")
u = sc[(sc.policy == "UT") & (np.isclose(sc.val, 0.5))].groupby("mult").checks.mean()
chk("UT checks, most stable", u.min(), 14, 0.5); chk("UT checks, fastest", u.max(), 167, 0.5)
pp = sc[(sc.policy == "periodic") & (sc.val == 120)]; uu = sc[(sc.policy == "UT") & np.isclose(sc.val, 0.55)]
chk("FFP periodic 120h", pp.FFP.mean(), 0.655, 0.0006); chk("FFP UT 0.55", uu.FFP.mean(), 0.718, 0.0006)
chk("accuracy compliance UT 0.55", uu.MPEcomp.mean(), 0.934, 0.0006); chk("accuracy compliance periodic 120h", pp.MPEcomp.mean(), 0.941, 0.0006)
chk("UT coverage 3x instrument (U=0.5)", sc[(sc.policy == "UT") & np.isclose(sc.val, 0.5) & (sc.mult == 3)].PICP.mean(), 0.898, 0.0006)
print(f"\n{ok} checks passed, {len(bad)} failed"); [print("  FAILED:", b) for b in bad]
