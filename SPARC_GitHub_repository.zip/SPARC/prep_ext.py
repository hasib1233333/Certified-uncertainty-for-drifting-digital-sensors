"""Prepare the two additional public field data sets as hourly series.
London (QMUL AQMS, CC BY 4.0): node_3 + TH2 (Mile End Road), node_5 + TH7 (King Edward Memorial Park).
Zurich (Empa Duebendorf, Mahajan & Helbing 2025, CC0): four SPS30 units + reference PM2.5."""
import pandas as pd, numpy as np, sys
src = sys.argv[1]; out = sys.argv[2]
cols = ["timestamp_utc", "no2_mid_alphasense_op1_voltage", "no2_mid_alphasense_op2_voltage",
        "o3_mid_alphasense_op1_voltage", "o3_mid_alphasense_op2_voltage",
        "temperature_low_sht45_celsius", "humidity_low_sht45_percentage",
        "pm2_5_low_sps30_ug_m3", "pm10_low_sps30_ug_m3"]
for node, ref, site in [("node_3", "th2.csv", "MER"), ("node_5", "node_TH7_KEMP.csv", "KEMP")]:
    d = pd.read_csv(f"{src}/qm/{node}.csv", usecols=cols)
    d["ts"] = pd.to_datetime(d.pop("timestamp_utc"), utc=True)
    d = d.set_index("ts").apply(pd.to_numeric, errors="coerce")
    h = d.resample("1h").mean()
    h["nsamp"] = d.iloc[:, 0].resample("1h").count()
    r = pd.read_csv(f"{src}/qm/{ref}")
    r["ts"] = pd.to_datetime(r["timestamp_utc"], utc=True)
    r = r.set_index("ts")[["no2_high_met_one_ug_m3", "pm2_5_high_met_one_ug_m3"]].apply(pd.to_numeric, errors="coerce")
    rh = r.resample("1h").mean(); rh["nref"] = r.iloc[:, 0].resample("1h").count()
    rh.columns = ["ref_no2", "ref_pm25", "nref"]
    j = h.join(rh, how="outer")
    j.loc[j["nsamp"] < 30, cols[1:]] = np.nan          # need >= 30 sensor rows (~1/3 h) per hour
    j.loc[j["nref"] < 3, ["ref_no2", "ref_pm25"]] = np.nan  # need >= 3 of 4 quarter-hours
    j.to_csv(f"{out}/london_{site}.csv")
    print(site, j.index[0], j.index[-1], len(j), "sensor ok", int(j[cols[1]].notna().sum()),
          "ref no2", int(j.ref_no2.notna().sum()), "ref pm", int(j.ref_pm25.notna().sum()))
z = pd.read_csv(f"{src}/ethpm/combined_data.csv")
z["ts"] = pd.to_datetime(z.pop("Date"), format="%d.%m.%Y %H:%M")
z = z.set_index("ts").sort_index().apply(pd.to_numeric, errors="coerce")
z = z.reindex(pd.date_range(z.index[0], z.index[-1], freq="h"))
z.to_csv(f"{out}/zurich_pm25.csv"); print("Zurich", z.index[0], z.index[-1], len(z), z.notna().sum().to_dict())
