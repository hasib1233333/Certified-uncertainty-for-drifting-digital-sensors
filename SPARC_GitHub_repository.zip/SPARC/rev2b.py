import numpy as np, pandas as pd
from scipy.optimize import nnls
from run_real import load, features, INIT, TARGETS
from sparc import run_stream
from synth import generate, periodic_windows, INIT as SI, U_REF
OUT="figure_data/"
D=load(); H=features(D)
rng=np.random.default_rng(1)
# ---- (6) block-length robustness of field CIs ----
L=[]
for tgt,(col,u) in TARGETS.items():
    y=D[col].values.astype(float)
    for per in [72,168,336]:
        res,ex=run_stream(H,y,INIT,list(range(INIT+per-24,len(y),per))); yt=y[INIT:]
        for B in [168,336,504]:
            nb=len(yt)//B
            def wk(k):
                _,lo,hi=res[k]; c=((yt>=lo)&(yt<=hi)).astype(float); c[np.isnan(yt)|np.isnan(lo)]=np.nan
                return c[:nb*B].reshape(nb,B)
            S,A,K=wk("SPARC"),wk("ACI"),wk("KF-GUM")
            usable=int(np.sum(np.isfinite(np.nanmean(S,1))))
            out=[]
            for X,Y in [(S,A),(S,K)]:
                d=[np.nanmean(X[i])-np.nanmean(Y[i]) for i in [rng.integers(0,nb,nb) for _ in range(2000)]]
                lo_,hi_=np.percentile(d,[2.5,97.5]); out.append(int(lo_>0) - int(hi_<0))
            L.append((tgt,per,B,usable,*out))
Bk=pd.DataFrame(L,columns=["t","p","B","nblocks","sigA","sigK"])
Bk.to_csv(OUT+"blocklen.csv",index=False)
print(Bk.groupby("B").agg(nb_min=("nblocks","min"),nb_max=("nblocks","max"),A_pos=("sigA",lambda s:(s>0).sum()),A_neg=("sigA",lambda s:(s<0).sum()),K_pos=("sigK",lambda s:(s>0).sum()),K_neg=("sigK",lambda s:(s<0).sum())))
# lag-1 autocorrelation of weekly coverage differences
ac=[]
for tgt,(col,u) in TARGETS.items():
    y=D[col].values.astype(float); res,ex=run_stream(H,y,INIT,list(range(INIT+168-24,len(y),168))); yt=y[INIT:]; nb=len(yt)//168
    def w(k):
        _,lo,hi=res[k]; c=((yt>=lo)&(yt<=hi)).astype(float); c[np.isnan(yt)|np.isnan(lo)]=np.nan; return np.nanmean(c[:nb*168].reshape(nb,168),1)
    dd=w("SPARC")-w("ACI"); dd=dd[np.isfinite(dd)]; ac.append(np.corrcoef(dd[:-1],dd[1:])[0,1])
print("lag1 autocorr weekly diff", np.round(ac,3))
