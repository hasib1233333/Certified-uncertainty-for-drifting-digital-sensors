"""Field evaluation on the UCI Air Quality multisensor dataset (De Vito et al., 2008)."""
import numpy as np, pandas as pd, sys
from scipy.stats import wilcoxon
from sparc import run_stream, interval_metrics, METHODS, age_coverage

INIT = 336
TARGETS = {"CO": ("CO(GT)", "mg/m$^3$"), "NO2": ("NO2(GT)", "$\\mu$g/m$^3$"),
           "NOx": ("NOx(GT)", "ppb"), "C6H6": ("C6H6(GT)", "$\\mu$g/m$^3$")}
SENS = ["PT08.S1(CO)", "PT08.S2(NMHC)", "PT08.S3(NOx)", "PT08.S4(NO2)", "PT08.S5(O3)"]


def load(path="data/AirQualityUCI_clean.csv"):
    df = pd.read_csv(path, encoding="utf-8-sig")
    df = df[[c for c in df.columns if not c.startswith("Unnamed")]].dropna(how="all")
    df["ts"] = pd.to_datetime(df["Date"] + " " + df["Time"], format="%m/%d/%Y %H:%M:%S")
    df = df.set_index("ts").sort_index()
    df = df.replace(-200, np.nan)
    full = pd.date_range(df.index[0], df.index[-1], freq="h")
    return df.reindex(full)


def features(df):
    X = [np.log(df[s].values) for s in SENS] + [df["T"].values, df["RH"].values, df["AH"].values]
    X = np.column_stack(X)
    return np.column_stack([np.ones(len(X)), X])


def weekly_blocks(y, lo, hi, alpha=0.05, B=168):
    m = ~np.isnan(y) & ~np.isnan(lo)
    w = hi - lo
    IS = w + (2 / alpha) * np.maximum(lo - y, 0) + (2 / alpha) * np.maximum(y - hi, 0)
    cov = ((y >= lo) & (y <= hi)).astype(float)
    IS[~m] = np.nan
    cov[~m] = np.nan
    nb = len(y) // B
    return (np.nanmean(IS[: nb * B].reshape(nb, B), 1), np.nanmean(cov[: nb * B].reshape(nb, B), 1),
            np.nanmean(np.where(m, w, np.nan)[: nb * B].reshape(nb, B), 1))


def block_boot_ci(x, nboot=2000, seed=0):
    x = x[~np.isnan(x)]
    rng = np.random.default_rng(seed)
    bs = [np.mean(rng.choice(x, len(x), replace=True)) for _ in range(nboot)]
    return np.percentile(bs, [2.5, 97.5])


def age_cov(y, lo, hi, ages, period, nb=5):
    m = ~np.isnan(lo) & ~np.isnan(y) & ~np.isnan(ages)
    cov = ((y >= lo) & (y <= hi))[m]
    edges = np.linspace(0, period + 24, nb + 1)
    b = np.clip(np.digitize(ages[m], edges) - 1, 0, nb - 1)
    return np.array([cov[b == i].mean() if np.any(b == i) else np.nan for i in range(nb)])


if __name__ == "__main__":
    df = load()
    H = features(df)
    print("hours", len(df), "from", df.index[0], "to", df.index[-1])
    rows, weekly, series = [], [], {}
    for tgt, (col, unit) in TARGETS.items():
        y = df[col].values.astype(float)
        for period in [72, 168, 336]:
            wins = list(range(INIT + period - 24, len(y), period))
            res, ex = run_stream(H, y, INIT, wins, u_ref=0.0)
            af, ages, nc = ex["af"], ex["ages"], ex["n_checks"]
            yt = y[INIT:]
            wk = {}
            for k in METHODS:
                if k == "SPARC-G":
                    continue
                yhat, lo, hi = res[k]
                mt = interval_metrics(yt, lo, hi)
                cb = age_coverage(yt, lo, hi, ages, period)
                ace = float(np.nanmax(np.abs(cb - 0.95)))
                rmse = float(np.sqrt(np.nanmean((yhat - yt) ** 2)))
                isw, covw, ww = weekly_blocks(yt, lo, hi)
                wk[k] = isw
                ci = block_boot_ci(covw)
                obj = ex["meths"].get(k, (None,))[0]
                rows.append(dict(target=tgt, period=period, method=k, PICP=mt["PICP"],
                                 viol=getattr(obj, "viol", 0) if obj is not None else 0,
                                 PICP_lo=ci[0], PICP_hi=ci[1], MPIW=mt["MPIW"], IS=mt["IS"],
                                 WorstWk=mt["WorstWk"], AFmis=float(np.mean(af[k])), nAF=len(af[k]),
                                 CHKmis=float(np.mean(ex["chk"][k])), nCHK=len(ex["chk"][k]),
                                 ACE=ace, RMSE=rmse, checks=nc, n=mt["n"],
                                 **{f"cb{i}": cb[i] for i in range(5)}))
                if period == 168:
                    series[(tgt, k)] = (yhat, lo, hi)
            for k in wk:
                if k == "SPARC":
                    continue
                a, b = wk["SPARC"], wk[k]
                mm = ~np.isnan(a) & ~np.isnan(b)
                st = wilcoxon(a[mm], b[mm])
                weekly.append(dict(target=tgt, period=period, method=k, p=st.pvalue,
                                   dIS=float(np.mean(a[mm] - b[mm])), n=int(mm.sum()),
                                   frac_better=float(np.mean(a[mm] < b[mm]))))
            kf = ex["kf"]
            series[(tgt, period, "budget")] = (kf.qz, kf.qs, kf.r0, float(np.nanmean(ex["kappa"])))
            sp = ex["meths"]["SPARC"][0]
            afF = [e for e in ex["af"]["SPARC"]]
            series[(tgt, period, "strata")] = (float(np.mean(ex["af"]["SPARC"])), len(ex["af"]["SPARC"]),
                                              float(np.mean(ex["chk"]["SPARC"])), len(ex["chk"]["SPARC"]))
            if period == 168:
                series[(tgt, "y")] = yt
                series[(tgt, "ages")] = ages
                series[(tgt, "kappa")] = ex["kappa"]
                series[(tgt, "u")] = ex["u"]
                series[(tgt, "starts")] = ex["starts"]
    pd.DataFrame(rows).to_pickle("results/real.pkl")
    pd.DataFrame(weekly).to_pickle("results/real_wilcoxon.pkl")
    pd.to_pickle(series, "results/real_series.pkl")
    pd.to_pickle(df.index, "results/real_index.pkl")
    print(pd.DataFrame(rows).pivot_table(index=["target", "period"], columns="method", values="PICP").round(3))
    print(pd.DataFrame(rows).pivot_table(index=["target", "period"], columns="method", values="IS").round(3))
