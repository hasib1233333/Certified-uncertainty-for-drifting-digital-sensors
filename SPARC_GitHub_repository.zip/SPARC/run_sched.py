"""Uncertainty-triggered reference checks vs periodic checks on a heterogeneous sensor network."""
import numpy as np, pandas as pd, time
from multiprocessing import Pool
from sparc import run_stream, interval_metrics
from synth import generate, periodic_windows, INIT, U_REF, TDEP

MULTS = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0]
MPE = 0.5          # maximum permissible error / target expanded uncertainty (mg/m^3)


def make_sched(Umax, N):
    def f(U, idx, tmin):
        c = np.where((idx >= tmin) & (U > Umax))[0]
        if len(c):
            return int(idx[c[0]])
        nxt = int(idx[-1]) + 1
        return nxt if nxt < N else None
    return f


def one(args):
    rep, i, policy, val = args
    H, y, yr = generate("S1", 1000 * rep + i, drift_mult=MULTS[i])
    N = len(y)
    if policy == "periodic":
        res, ex = run_stream(H, yr, INIT, periodic_windows(val), u_ref=U_REF)
    else:
        res, ex = run_stream(H, yr, INIT, scheduler=make_sched(val, N), u_ref=U_REF)
    yhat, lo, hi = res["SPARC"]
    yt = y[INIT:]
    m = interval_metrics(yt, lo, hi)
    hw = (hi - lo) / 2
    ok = ~np.isnan(hw)
    return dict(rep=rep, sensor=i, mult=MULTS[i], policy=policy, val=val,
                checks=ex["n_checks"] * 8760 / TDEP, PICP=m["PICP"], MPIW=m["MPIW"], IS=m["IS"],
                FFP=float(np.mean(hw[ok] <= MPE)), MPEcomp=float(np.mean(np.abs(yhat[ok] - yt[ok]) <= MPE)),
                RMSE=float(np.sqrt(np.nanmean((yhat - yt) ** 2))))


if __name__ == "__main__":
    jobs = []
    for rep in range(6):
        for i in range(len(MULTS)):
            for P in [72, 120, 168, 240, 336, 504]:
                jobs.append((rep, i, "periodic", P))
            for U in [0.40, 0.45, 0.50, 0.55, 0.60, 0.70]:
                jobs.append((rep, i, "UT", U))
    t0 = time.time()
    with Pool(2) as p:
        out = p.map(one, jobs, chunksize=2)
    df = pd.DataFrame(out)
    df.to_pickle("results/sched.pkl")
    print("done %.0f s" % (time.time() - t0))
    g = df.groupby(["policy", "val"]).mean(numeric_only=True)[["checks", "PICP", "MPIW", "FFP", "MPEcomp", "RMSE"]]
    print(g.round(3))
