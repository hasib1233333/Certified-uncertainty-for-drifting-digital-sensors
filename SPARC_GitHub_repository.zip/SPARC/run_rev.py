"""Revision experiments: buffer size M, Gaussian check of SPARC-G, paired CIs."""
import numpy as np, pandas as pd, sys, time
from multiprocessing import Pool
import sparc
from sparc import run_stream, interval_metrics
from synth import generate, periodic_windows, INIT, U_REF

def one(args):
    sc, seed, M, um = args
    sparc.BUF_M = M
    H, y, yr = generate(sc, seed)
    if um != 1.0:
        rng = np.random.default_rng(10_000 + seed); yr = y + rng.normal(0, U_REF * um, len(y))
    res, ex = run_stream(H, yr, INIT, periodic_windows(168), u_ref=U_REF * um)
    out = []
    for k in ["ACI", "KF-GUM", "SPARC", "SPARC-G"]:
        m = interval_metrics(y[INIT:], *res[k][1:]); mr = interval_metrics(yr[INIT:], *res[k][1:])
        out.append(dict(sc=sc, seed=seed, M=M, um=um, method=k, PICP=m["PICP"], PICPref=mr["PICP"], IS=m["IS"],
                        MPIW=m["MPIW"], AF=float(np.mean(ex["af"][k]))))
    return out

if __name__ == "__main__":
    jobs = [("S1", s, M, 1.0) for M in [250, 500, 2000] for s in range(30)]
    jobs += [("S0", s, 1000, um) for um in [1.0, 2.0, 3.0] for s in range(30)]
    t0 = time.time()
    with Pool(2) as p:
        r = p.map(one, jobs, chunksize=2)
    pd.DataFrame([x for y in r for x in y]).to_pickle("results/rev.pkl")
    print("done %.0f s" % (time.time() - t0))
